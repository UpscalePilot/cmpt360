#####################################################################
#           CMPT 360    - Lab 1               			            #
#           Ben Morley  - ID 3142870								#
#			Nabil Gelle - ID 3104375                                #
#                                                                   #
#####################################################################

To install use
make

To run program use 
make run    OR      ./test_dStruct

To remove all .o files 
make clean

