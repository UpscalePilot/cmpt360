#####################################################################
#           Ben Morley - CMPT 360 - Lab #                           #
#           ID 3142870                                              #
#                                                                   #
#####################################################################

To install use
make

To run program use 
./fileType <path to file>

To remove all .o files 
make clean

