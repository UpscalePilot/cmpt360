# Ben Morley

## CMPT 360 Lab 7

## To install use

make

### To run program use

make run    OR      ./test_pi

### To remove all .o files

make clean
