# Ben Morley Lab 2

## To install use
make

## To run the process simulator:
make run    OR      ./procSim

## To run the plot data app:
make plot 	OR 		./plotData

## To remove all .o files 
make clean

